import React from "react";
import Images from "../../Containers/Gallery/Images/Images";

import "./Album.css";

const Album = (props) => {
  return (
    <div className="container">
      <h3 className="title">{props.albumName}</h3>
      <div className="carousel">
        {props.images.length > 0 ? (
          <Images images={props.images} />
        ) : (
          <p>sorry theres is no pic for this album</p>
        )}
      </div>
    </div>
  );
};

export default Album;
