import React from 'react';

const contact = (props) => {
    return (
        <address>
            instagram.com
        </address>
    )
}

export default contact;