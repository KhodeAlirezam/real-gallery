import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./Header.css";

const Header = (props) => {
  const [open, setOpen] = useState(false);

  const style = !open
    ? { transition: `transform 0.5s ease-in-out` }
    : { transform: `translateX(0%)`, transition: `transform 0.5s ease-in-out` };

  const handleClick = () => {
    setOpen((prev) => !prev);
  };

  return (
    <nav className="Header">
      <NavLink className="Nav-Link" to="/" exact>
        <h2 className="Logo">{props.title}</h2>
      </NavLink>
      <ul style={style} className="Nav-Links" onClick={handleClick}>
        <li>
          <NavLink className="Nav-Link" to="/Exhibitions" exact>
            EXHIBITIONS
          </NavLink>
        </li>
        <li>
          <NavLink className="Nav-Link" to="/Paintings" exact>
            PAINTINGS
          </NavLink>
        </li>
        <li>
          <NavLink className="Nav-Link" to="/Sculptures" exact>
            SCULPTURES
          </NavLink>
        </li>
        <li>
          <NavLink className="Nav-Link" to="/Contact" exact>
            CONTACT
          </NavLink>
        </li>
        <li>
          <NavLink className="Nav-Link" to="/About" exact>
            ABOUT
          </NavLink>
        </li>
      </ul>
      <div className="burger" onClick={handleClick}>
        <div className="burger-line"></div>
        <div className="burger-line"></div>
        <div className="burger-line"></div>
      </div>
    </nav>
  );
};

export default Header;
